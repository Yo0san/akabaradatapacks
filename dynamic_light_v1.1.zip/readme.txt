--------------------------------------------------
Dynamic light v1.1

Thank you for downloading this datapack. I hope you like it.
If you have any ideas or found any issues feel free to contact me.

This datapack adds full dynamic light to your world.

---> Features
-Full features of dynamic light, like in Optifine
-Fast and fancy profiles
-Easy to add new (or modify) glowing entities and items
-Special features for map makers
-Multiplayer support
-Performance and optimization (however in this case a real bottleneck is the minecraft light system itself)

---> Profile switching
Use:
/function dynlight:profile/off
/function dynlight:profile/fast
/function dynlight:profile/fancy
After installation the fast profile is enabled by default.

---> Supported Minecraft versions
1.17+

---> Multiplayer
Full multiplayer support

---> Mods
Full mods support; Add mod items and entities to the corresponding tags (see "doc.txt" for more info).

---> Uninstalling
1. In your world run: /function dynlight:uninstall
2. Leave the world.
2. Remove the datapack file from the datapacks folder of your world.

---> Credits
Created by Fiktel.

Find new updates as well as more hight quality datapacks on my Planet Minecraft profile:
https://www.planetminecraft.com/member/fiktel/


--------------------------------------------------
How to install datapacks?
1. Open Minecraft.
2. Select the world you want to install the data pack for, click on "Edit", then "Open world folder".
3. Open the folder named datapacks, and put the data pack (.zip file) into it.
4. Load the world.

More help:
https://minecraft.fandom.com/wiki/Tutorials/Installing_a_data_pack

